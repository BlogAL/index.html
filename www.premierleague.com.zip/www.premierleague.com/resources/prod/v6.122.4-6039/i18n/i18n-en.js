if (!PULSE) { var PULSE = {}; }
PULSE.I18N =
{"language":"en","accountId":4,"translations":{}};
